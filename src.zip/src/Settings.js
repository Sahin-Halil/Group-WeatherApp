import React from "react";

const Settings = () => {
  return (
    <div>
      <h1>Settings Page</h1>
      <p>This is where user settings will go.</p>
    </div>
  );
};

export default Settings;