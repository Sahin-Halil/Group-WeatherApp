import React from "react";

const Activities = () => {
  return (
    <div>
      <h1>Activities Page</h1>
      <p>This is where activity recommendations will go.</p>
    </div>
  );
};

export default Activities;